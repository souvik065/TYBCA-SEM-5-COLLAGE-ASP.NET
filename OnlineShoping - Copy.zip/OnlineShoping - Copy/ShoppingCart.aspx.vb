﻿
Partial Class ShoppingCart
    Inherits System.Web.UI.Page

End Class
